public class FizzBuzz {

    String validateFizzBuzz(int number) {
        if (number == 3) {
            return "Fizz";
        }
        return String.valueOf(number);
    }
}